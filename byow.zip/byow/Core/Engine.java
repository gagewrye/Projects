package byow.Core;

import byow.Core.Objects.Player;
import byow.TileEngine.Tileset;
import byow.TileEngine.dTERenderer;
import byow.TileEngine.TETile;
import edu.princeton.cs.algs4.StdDraw;

import java.awt.*;
import java.util.Random;

import static edu.princeton.cs.algs4.StdDraw.hasNextKeyTyped;
import static edu.princeton.cs.algs4.StdDraw.nextKeyTyped;

public class Engine {


    dTERenderer ter = new dTERenderer();
    /* Feel free to change the width and height. */
    public static final int WIDTH = Toolkit.getDefaultToolkit().getScreenSize().width;
    public static final int HEIGHT = Toolkit.getDefaultToolkit().getScreenSize().height
            - (Toolkit.getDefaultToolkit().getScreenSize().height / 10);

    /**
     * Method used for exploring a fresh world. This method should handle all inputs,
     * including inputs from the main menu.
     */
    public void interactWithKeyboard() {
        // display main menu with:
        // 1. New game (N)
        // 2. Load Game (L)
        // 3. Quit (Q)
        // 4. Character (C)

        // initialize canvas
        StdDraw.setCanvasSize(WIDTH, HEIGHT);
        StdDraw.setXscale(0, WIDTH);
        StdDraw.setYscale(0, HEIGHT);
        StdDraw.clear(Color.BLACK);
        StdDraw.setPenColor(Color.WHITE);
        // fonts
        Font fontBig = new Font("Monaco", Font.BOLD, HEIGHT / 8);
        Font fontSmall = new Font("Monaco", Font.PLAIN, HEIGHT / 15);
        //create text
        StdDraw.setFont(fontBig);
        StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 5.0), "CS61B: THE GAME");
        StdDraw.setFont(fontSmall);
        StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 1.7), "New Game (N)");
        StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 1.5), "Load Game (L)");
        StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 1.345), "Character (C)");
        StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 1.24), "Quit (Q)");
        StdDraw.show();

        // initializes main menu and requests input
        boolean mainMenu = true;
        boolean namingPlayer = false;
        TETile avatar = Tileset.AVATAR;
        String playerName = "Player 1";
        while (mainMenu) {
            // brings up character customization menu
            if (namingPlayer) {
                StringBuilder name = new StringBuilder();
                while (namingPlayer) {
                    StdDraw.clear(Color.BLACK);
                    StdDraw.setFont(fontBig);
                    StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 5.0), "Enter a name:");
                    StdDraw.setFont(fontSmall);
                    StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 2.0), String.valueOf(name));
                    StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 1.5), "press ;" +
                            " to confirm");
                    StdDraw.show();
                    StdDraw.pause(100);
                    if (hasNextKeyTyped()) {
                        char c = nextKeyTyped();
                        if (c == ';') {
                            namingPlayer = false;
                        } else {
                            name.append(c);
                        }
                    }
                }
                boolean changingAvatar = true;
                while (changingAvatar) {
                    StdDraw.clear(Color.BLACK);
                    StdDraw.setFont(fontBig);
                    StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 5.0), "Select a character:");
                    StdDraw.setFont(fontSmall);
                    StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 1.7), "default @ (d)");
                    StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 1.5), "grass (g)");
                    StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 1.345), "flower (f)");
                    StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 1.24), "triangle (t)");
                    StdDraw.show();
                    StdDraw.pause(100);
                    if (hasNextKeyTyped()) {
                        char c = nextKeyTyped();
                        switch (c) {
                            case 'd', 'D' -> changingAvatar = false;
                            case 'g', 'G' -> {
                                avatar = Tileset.GRASS;
                                changingAvatar = false;
                            }
                            case 'f', 'F' -> {
                                avatar = Tileset.FLOWER;
                                changingAvatar = false;
                            }
                            case 't', 'T' -> {
                                avatar = Tileset.MOUNTAIN;
                                changingAvatar = false;
                            }
                            default -> {
                            }
                        }
                    }
                }
                playerName = name.toString();
                // back to main menu
                StdDraw.clear(Color.black);
                StdDraw.setFont(fontBig);
                StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 5.0), "CS61B: THE GAME");
                StdDraw.setFont(fontSmall);
                StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 1.7), "New Game (N)");
                StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 1.5), "Load Game (L)");
                StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 1.345), "Character (C)");
                StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 1.24), "Quit (Q)");
                StdDraw.textLeft(2,HEIGHT - (HEIGHT / 1.05), "Player Name: " + playerName);
                StdDraw.show();
            }
            if (hasNextKeyTyped()) {
                switch (nextKeyTyped()) {
                    case 'c':
                    case 'C':
                        namingPlayer = true;
                        break;
                    case 'n':// create new game
                    case 'N':
                        // request a seed
                        StringBuilder input = new StringBuilder();
                        while (true) {
                            StdDraw.clear(Color.BLACK);
                            StdDraw.setFont(fontBig);
                            StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 5.0), "Enter a seed:");
                            StdDraw.setFont(fontSmall);
                            StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 2.0), String.valueOf(input));
                            StdDraw.text(WIDTH / 2.0, HEIGHT - (HEIGHT / 1.5), "press S to confirm");
                            StdDraw.show();
                            StdDraw.pause(100);
                            if (hasNextKeyTyped()) {
                                char c = nextKeyTyped();
                                switch (c) {
                                    case '0':
                                    case '1':
                                    case '2':
                                    case '3':
                                    case '4':
                                    case '5':
                                    case '6':
                                    case '7':
                                    case '8':
                                    case '9':
                                        input.append(c);
                                        break;
                                    case 'S':
                                    case 's':// generate world with string
                                        if (input.isEmpty()){
                                            break;
                                        }
                                        // Use seed to generate a new dungeon
                                        long seed = Long.parseLong(input.toString());
                                        Random seed1 = new Random(seed);
                                        DungeonGenerator newWorld = new DungeonGenerator(seed1);
                                        newWorld.setMaximumX((HEIGHT / 20) - 15);
                                        newWorld.setMaximumY((WIDTH / 15) - 15);
                                        Dungeon dungeon = newWorld.generateDungeon(seed1.nextInt(10, 15));
                                        TETile[][] map = dungeon.getMap();
                                        // initial setup for the game
                                        dungeon.getMyPlayer().name = playerName;
                                        dungeon.getMyPlayer().setAvatar(avatar);
                                        boolean gameOver = false;
                                        boolean colon = false;
                                        ter.initialize(map.length + 2, map[0].length + 1, 1, 1);
                                        while (!gameOver) {
                                            map = dungeon.getMap();
                                            ter.renderFrame(map, dungeon);
                                            if (hasNextKeyTyped()) {
                                                switch (nextKeyTyped()) {
                                                    case 'w':
                                                    case 'W':
                                                        dungeon.getMyPlayer().move(0, 1);
                                                        colon = false;
                                                        break;
                                                    case 's':
                                                        dungeon.getMyPlayer().move(0, -1);
                                                        colon = false;
                                                        break;
                                                    case 'd':
                                                        dungeon.getMyPlayer().move(1, 0);
                                                        colon = false;
                                                        break;
                                                    case 'a':
                                                        dungeon.getMyPlayer().move(-1, 0);
                                                        colon = false;
                                                        break;
                                                    case ':':
                                                        colon = true;
                                                        break;
                                                    case 'l':
                                                    case 'L':
                                                        dungeon.lightSwitch();
                                                        break;
                                                    case 'q':
                                                    case 'Q':
                                                        if (colon) {
                                                            gameOver = true;
                                                            // TODO: find a way to quit/save the game
                                                        }
                                                        break;
                                                    default:
                                                        break;
                                                }
                                                if (dungeon.getMyPlayer().getHealth() <= 0) {
                                                    gameOver = true;
                                                }
                                            }
                                        }
                                        interactWithKeyboard();
                                    default:
                                        break;


                                }
                            }
                        }
                    case 'l': // TODO: load save file
                    case 'L':
                        break;
                    case 'q':
                    case 'Q':
                        return;
                    default:
                        break;
                }
            }
        }
    }

    /**
     * Method used for autograding and testing your code. The input string will be a series
     * of characters (for example, "n123sswwdasdassadwas", "n123sss:q", "lwww". The engine should
     * behave exactly as if the user typed these characters into the engine using
     * interactWithKeyboard.
     *
     * Recall that strings ending in ":q" should cause the game to quite save. For example,
     * if we do interactWithInputString("n123sss:q"), we expect the game to run the first
     * 7 commands (n123sss) and then quit and save. If we then do
     * interactWithInputString("l"), we should be back in the exact same state.
     *
     * In other words, both of these calls:
     *   - interactWithInputString("n123sss:q")
     *   - interactWithInputString("lww")
     *
     * should yield the exact same world state as:
     *   - interactWithInputString("n123sssww")
     *
     * @param input the input string to feed to your program
     * @return the 2D TETile[][] representing the state of the world
     */
    public TETile[][] interactWithInputString(String input) {
        String playerName = "Player 1";
        char[] inputs = input.toCharArray();
        for (int i = 0; i < inputs.length; i++) {
            if (inputs[i] == 'n' || inputs[i] == 'N') {
                input = input.substring(1);
                StringBuilder seedString = new StringBuilder();
                while (true) {
                    i++;
                    switch (inputs[i]) {
                        case '0':
                        case '1':
                        case '2':
                        case '3':
                        case '4':
                        case '5':
                        case '6':
                        case '7':
                        case '8':
                        case '9':
                            seedString.append(inputs[i]);
                            break;

                        case 'S':
                        case 's':// generate world with string
                            long seed = Long.parseLong(seedString.toString());
                            Random seed1 = new Random(seed);
                            DungeonGenerator newWorld = new DungeonGenerator(seed1);
                            Dungeon dungeon = newWorld.generateDungeon(seed1.nextInt(10, 15));
                            TETile[][] map = dungeon.getMap();
                            // initial setup for the game
                            dungeon.getMyPlayer().name = playerName;
                            boolean gameOver = false;
                            boolean colon = false;
                            ter.initialize(map.length + 2, map[0].length + 1, 1, 1);
                            while (!gameOver) {
                                map = dungeon.getMap();
                                ter.renderFrame(map, dungeon);
                                switch (inputs[i]) {
                                    case 'w':
                                    case 'W':
                                        dungeon.getMyPlayer().move(0, 1);
                                        colon = false;
                                        break;
                                    case 'S':
                                    case 's':
                                        dungeon.getMyPlayer().move(0, -1);
                                        colon = false;
                                        break;
                                    case 'd':
                                    case 'D':
                                        dungeon.getMyPlayer().move(1, 0);
                                        colon = false;
                                        break;
                                    case 'a':
                                    case 'A':
                                        dungeon.getMyPlayer().move(-1, 0);
                                        colon = false;
                                        break;
                                    case ':':
                                        colon = true;
                                        break;
                                    case 'l':
                                    case 'L':
                                        dungeon.lightSwitch();
                                        break;
                                    case 'q':
                                    case 'Q':
                                        if (colon) {
                                            gameOver = true;
                                            // TODO: find a way to quit/save the game
                                        }
                                        break;
                                    default:
                                        break;
                                }
                                if (dungeon.getMyPlayer().getHealth() <= 0) {
                                    gameOver = true;
                                }
                            }
                    }
                    break;
                }
            }
            if (inputs[i] == 'l' || inputs[i] == 'L') {
                // TODO: Load game
            }
            if (inputs[i] == 'q' || inputs[i] == 'Q') {
                return null;
            }
        }
        return null;
    }
}
